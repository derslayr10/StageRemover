# StageRemover
 A simple mod that removes stages from the destination pool in RoR2. Currently only works for Sundered Grove.
